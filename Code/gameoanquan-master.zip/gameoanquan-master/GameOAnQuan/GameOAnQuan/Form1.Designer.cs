﻿
namespace GameOAnQuan
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label7;
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnreset = new System.Windows.Forms.Button();
            this.btnchoilai = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.t2 = new System.Windows.Forms.Label();
            this.t1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbldiemmay = new System.Windows.Forms.Label();
            this.lbldiemnguoichoi = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.nguoichoi = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.anh2 = new System.Windows.Forms.PictureBox();
            this.anh7 = new System.Windows.Forms.PictureBox();
            this.anh8 = new System.Windows.Forms.PictureBox();
            this.anh9 = new System.Windows.Forms.PictureBox();
            this.anh10 = new System.Windows.Forms.PictureBox();
            this.anh11 = new System.Windows.Forms.PictureBox();
            this.anh5 = new System.Windows.Forms.PictureBox();
            this.anh4 = new System.Windows.Forms.PictureBox();
            this.anh3 = new System.Windows.Forms.PictureBox();
            this.anh1 = new System.Windows.Forms.PictureBox();
            this.anhnguoimay = new System.Windows.Forms.PictureBox();
            this.anhnguoichoi = new System.Windows.Forms.PictureBox();
            this.anhsoluongsoicuamay = new System.Windows.Forms.PictureBox();
            this.anhsoluongsoicuanguoi = new System.Windows.Forms.PictureBox();
            this.anh12 = new GameOAnQuan.Circularpictureleft();
            this.circularpictureleft1 = new GameOAnQuan.Circularpictureleft();
            this.anh6 = new GameOAnQuan.Circularpictureright();
            this.circularpictureright1 = new GameOAnQuan.Circularpictureright();
            this.elipseControl1 = new GameOAnQuan.ElipseControl();
            this.elipseControl2 = new GameOAnQuan.ElipseControl();
            this.elipseControl3 = new GameOAnQuan.ElipseControl();
            this.elipseControl4 = new GameOAnQuan.ElipseControl();
            this.elipseControl5 = new GameOAnQuan.ElipseControl();
            this.elipseControl6 = new GameOAnQuan.ElipseControl();
            this.elipseControl7 = new GameOAnQuan.ElipseControl();
            this.elipseControl8 = new GameOAnQuan.ElipseControl();
            label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhnguoimay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhnguoichoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhsoluongsoicuamay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhsoluongsoicuanguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circularpictureleft1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circularpictureright1)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            label7.Location = new System.Drawing.Point(20, 75);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(107, 25);
            label7.TabIndex = 6;
            label7.Text = "Người/Máy";
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.Transparent;
            this.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn11.Location = new System.Drawing.Point(318, 225);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(62, 44);
            this.btn11.TabIndex = 1;
            this.btn11.Text = "5";
            this.btn11.UseVisualStyleBackColor = false;
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.Color.Transparent;
            this.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn10.Location = new System.Drawing.Point(469, 225);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(67, 44);
            this.btn10.TabIndex = 3;
            this.btn10.Text = "5";
            this.btn10.UseVisualStyleBackColor = false;
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Transparent;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn3.Location = new System.Drawing.Point(620, 809);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(62, 47);
            this.btn3.TabIndex = 6;
            this.btn3.Text = "5";
            this.btn3.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.Transparent;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn9.Location = new System.Drawing.Point(624, 225);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(62, 44);
            this.btn9.TabIndex = 5;
            this.btn9.Text = "5";
            this.btn9.UseVisualStyleBackColor = false;
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Transparent;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn4.Location = new System.Drawing.Point(785, 808);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(63, 48);
            this.btn4.TabIndex = 8;
            this.btn4.Text = "5";
            this.btn4.UseVisualStyleBackColor = false;
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.Transparent;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn8.Location = new System.Drawing.Point(789, 225);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(63, 44);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "5";
            this.btn8.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.Transparent;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn5.Location = new System.Drawing.Point(944, 808);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(62, 47);
            this.btn5.TabIndex = 10;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.Transparent;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn7.Location = new System.Drawing.Point(948, 225);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(62, 44);
            this.btn7.TabIndex = 9;
            this.btn7.Text = "5";
            this.btn7.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Controls.Add(this.btnreset);
            this.panel1.Controls.Add(this.btnchoilai);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.t2);
            this.panel1.Controls.Add(this.t1);
            this.panel1.Controls.Add(label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(1416, 332);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 3, 100, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(321, 409);
            this.panel1.TabIndex = 12;
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnreset.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnreset.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnreset.Location = new System.Drawing.Point(25, 229);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(102, 53);
            this.btnreset.TabIndex = 11;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btnchoilai
            // 
            this.btnchoilai.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnchoilai.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnchoilai.FlatAppearance.BorderSize = 0;
            this.btnchoilai.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnchoilai.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnchoilai.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnchoilai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnchoilai.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnchoilai.Location = new System.Drawing.Point(25, 144);
            this.btnchoilai.Name = "btnchoilai";
            this.btnchoilai.Size = new System.Drawing.Size(102, 56);
            this.btnchoilai.TabIndex = 10;
            this.btnchoilai.Text = "Chơi Lại";
            this.btnchoilai.UseVisualStyleBackColor = false;
            this.btnchoilai.Click += new System.EventHandler(this.btnchoilai_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(181, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 25);
            this.label10.TabIndex = 9;
            this.label10.Text = "/";
            // 
            // t2
            // 
            this.t2.AutoSize = true;
            this.t2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.t2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.t2.Location = new System.Drawing.Point(203, 75);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(23, 25);
            this.t2.TabIndex = 8;
            this.t2.Text = "0";
            // 
            // t1
            // 
            this.t1.AutoSize = true;
            this.t1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.t1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.t1.Location = new System.Drawing.Point(159, 75);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(23, 25);
            this.t1.TabIndex = 7;
            this.t1.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(94, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "Tỉ số";
            // 
            // lbldiemmay
            // 
            this.lbldiemmay.AutoSize = true;
            this.lbldiemmay.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F);
            this.lbldiemmay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbldiemmay.Location = new System.Drawing.Point(1274, 159);
            this.lbldiemmay.Name = "lbldiemmay";
            this.lbldiemmay.Size = new System.Drawing.Size(51, 55);
            this.lbldiemmay.TabIndex = 4;
            this.lbldiemmay.Text = "0";
            // 
            // lbldiemnguoichoi
            // 
            this.lbldiemnguoichoi.AutoSize = true;
            this.lbldiemnguoichoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F);
            this.lbldiemnguoichoi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbldiemnguoichoi.Location = new System.Drawing.Point(1298, 895);
            this.lbldiemnguoichoi.Name = "lbldiemnguoichoi";
            this.lbldiemnguoichoi.Size = new System.Drawing.Size(51, 55);
            this.lbldiemnguoichoi.TabIndex = 1;
            this.lbldiemnguoichoi.Text = "0";
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Transparent;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn1.Location = new System.Drawing.Point(314, 804);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(62, 47);
            this.btn1.TabIndex = 2;
            this.btn1.Text = "5";
            this.btn1.UseVisualStyleBackColor = false;
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Transparent;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn2.Location = new System.Drawing.Point(470, 804);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(62, 47);
            this.btn2.TabIndex = 4;
            this.btn2.Text = "5";
            this.btn2.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.anh2);
            this.panel2.Controls.Add(this.anh7);
            this.panel2.Controls.Add(this.anh8);
            this.panel2.Controls.Add(this.anh9);
            this.panel2.Controls.Add(this.anh10);
            this.panel2.Controls.Add(this.anh11);
            this.panel2.Controls.Add(this.anh5);
            this.panel2.Controls.Add(this.anh4);
            this.panel2.Controls.Add(this.anh3);
            this.panel2.Controls.Add(this.anh1);
            this.panel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(303, 307);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(805, 456);
            this.panel2.TabIndex = 17;
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.Transparent;
            this.btn6.Enabled = false;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn6.Location = new System.Drawing.Point(1303, 506);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(82, 56);
            this.btn6.TabIndex = 52;
            this.btn6.Text = "1";
            this.btn6.UseVisualStyleBackColor = false;
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.Color.Transparent;
            this.btn12.Enabled = false;
            this.btn12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn12.Location = new System.Drawing.Point(12, 506);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(78, 56);
            this.btn12.TabIndex = 54;
            this.btn12.Text = "1";
            this.btn12.UseVisualStyleBackColor = false;
            // 
            // nguoichoi
            // 
            this.nguoichoi.AutoSize = true;
            this.nguoichoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nguoichoi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.nguoichoi.Location = new System.Drawing.Point(348, 24);
            this.nguoichoi.Name = "nguoichoi";
            this.nguoichoi.Size = new System.Drawing.Size(0, 69);
            this.nguoichoi.TabIndex = 12;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::GameOAnQuan.Properties.Resources.icons8_minimize_window_96;
            this.pictureBox2.Location = new System.Drawing.Point(1614, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Padding = new System.Windows.Forms.Padding(0, 18, 0, 0);
            this.pictureBox2.Size = new System.Drawing.Size(59, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 59;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GameOAnQuan.Properties.Resources.icons8_close_window_100;
            this.pictureBox1.Location = new System.Drawing.Point(1697, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Padding = new System.Windows.Forms.Padding(0, 18, 0, 0);
            this.pictureBox1.Size = new System.Drawing.Size(56, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 58;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // anh2
            // 
            this.anh2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anh2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.anh2.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh2.Location = new System.Drawing.Point(171, 237);
            this.anh2.Name = "anh2";
            this.anh2.Size = new System.Drawing.Size(143, 197);
            this.anh2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh2.TabIndex = 36;
            this.anh2.TabStop = false;
            this.anh2.Click += new System.EventHandler(this.anh2_Click_1);
            // 
            // anh7
            // 
            this.anh7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anh7.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh7.Location = new System.Drawing.Point(649, 20);
            this.anh7.Name = "anh7";
            this.anh7.Size = new System.Drawing.Size(135, 196);
            this.anh7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh7.TabIndex = 44;
            this.anh7.TabStop = false;
            // 
            // anh8
            // 
            this.anh8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anh8.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh8.Location = new System.Drawing.Point(487, 20);
            this.anh8.Name = "anh8";
            this.anh8.Size = new System.Drawing.Size(139, 196);
            this.anh8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh8.TabIndex = 43;
            this.anh8.TabStop = false;
            // 
            // anh9
            // 
            this.anh9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anh9.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh9.Location = new System.Drawing.Point(332, 22);
            this.anh9.Name = "anh9";
            this.anh9.Size = new System.Drawing.Size(137, 194);
            this.anh9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh9.TabIndex = 42;
            this.anh9.TabStop = false;
            // 
            // anh10
            // 
            this.anh10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anh10.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh10.Location = new System.Drawing.Point(171, 20);
            this.anh10.Name = "anh10";
            this.anh10.Size = new System.Drawing.Size(143, 198);
            this.anh10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh10.TabIndex = 41;
            this.anh10.TabStop = false;
            // 
            // anh11
            // 
            this.anh11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anh11.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh11.Location = new System.Drawing.Point(22, 20);
            this.anh11.Name = "anh11";
            this.anh11.Size = new System.Drawing.Size(131, 196);
            this.anh11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh11.TabIndex = 40;
            this.anh11.TabStop = false;
            // 
            // anh5
            // 
            this.anh5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anh5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.anh5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.anh5.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh5.Location = new System.Drawing.Point(649, 235);
            this.anh5.Name = "anh5";
            this.anh5.Size = new System.Drawing.Size(135, 197);
            this.anh5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh5.TabIndex = 39;
            this.anh5.TabStop = false;
            this.anh5.Click += new System.EventHandler(this.anh5_Click_1);
            // 
            // anh4
            // 
            this.anh4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anh4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.anh4.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh4.Location = new System.Drawing.Point(487, 237);
            this.anh4.Name = "anh4";
            this.anh4.Size = new System.Drawing.Size(139, 197);
            this.anh4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh4.TabIndex = 38;
            this.anh4.TabStop = false;
            this.anh4.Click += new System.EventHandler(this.anh4_Click_1);
            // 
            // anh3
            // 
            this.anh3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anh3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.anh3.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh3.Location = new System.Drawing.Point(332, 235);
            this.anh3.Name = "anh3";
            this.anh3.Size = new System.Drawing.Size(137, 197);
            this.anh3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh3.TabIndex = 37;
            this.anh3.TabStop = false;
            this.anh3.Click += new System.EventHandler(this.anh3_Click_1);
            // 
            // anh1
            // 
            this.anh1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anh1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.anh1.Image = global::GameOAnQuan.Properties.Resources.anh5;
            this.anh1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anh1.Location = new System.Drawing.Point(22, 235);
            this.anh1.Name = "anh1";
            this.anh1.Size = new System.Drawing.Size(131, 197);
            this.anh1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh1.TabIndex = 35;
            this.anh1.TabStop = false;
            this.anh1.Click += new System.EventHandler(this.anh1_Click_1);
            // 
            // anhnguoimay
            // 
            this.anhnguoimay.Image = global::GameOAnQuan.Properties.Resources.anhmay;
            this.anhnguoimay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anhnguoimay.Location = new System.Drawing.Point(76, 60);
            this.anhnguoimay.Name = "anhnguoimay";
            this.anhnguoimay.Size = new System.Drawing.Size(190, 209);
            this.anhnguoimay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anhnguoimay.TabIndex = 0;
            this.anhnguoimay.TabStop = false;
            // 
            // anhnguoichoi
            // 
            this.anhnguoichoi.Image = global::GameOAnQuan.Properties.Resources.anhnguoi;
            this.anhnguoichoi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anhnguoichoi.Location = new System.Drawing.Point(77, 804);
            this.anhnguoichoi.Name = "anhnguoichoi";
            this.anhnguoichoi.Size = new System.Drawing.Size(186, 214);
            this.anhnguoichoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anhnguoichoi.TabIndex = 0;
            this.anhnguoichoi.TabStop = false;
            // 
            // anhsoluongsoicuamay
            // 
            this.anhsoluongsoicuamay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anhsoluongsoicuamay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anhsoluongsoicuamay.Location = new System.Drawing.Point(1067, 41);
            this.anhsoluongsoicuamay.Name = "anhsoluongsoicuamay";
            this.anhsoluongsoicuamay.Size = new System.Drawing.Size(185, 228);
            this.anhsoluongsoicuamay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anhsoluongsoicuamay.TabIndex = 16;
            this.anhsoluongsoicuamay.TabStop = false;
            // 
            // anhsoluongsoicuanguoi
            // 
            this.anhsoluongsoicuanguoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anhsoluongsoicuanguoi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.anhsoluongsoicuanguoi.Location = new System.Drawing.Point(1082, 808);
            this.anhsoluongsoicuanguoi.Name = "anhsoluongsoicuanguoi";
            this.anhsoluongsoicuanguoi.Size = new System.Drawing.Size(186, 215);
            this.anhsoluongsoicuanguoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anhsoluongsoicuanguoi.TabIndex = 15;
            this.anhsoluongsoicuanguoi.TabStop = false;
            // 
            // anh12
            // 
            this.anh12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.anh12.Image = global::GameOAnQuan.Properties.Resources.anhchu2_1;
            this.anh12.ImageLocation = "";
            this.anh12.InitialImage = null;
            this.anh12.Location = new System.Drawing.Point(-74, 327);
            this.anh12.Name = "anh12";
            this.anh12.Size = new System.Drawing.Size(377, 409);
            this.anh12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh12.TabIndex = 55;
            this.anh12.TabStop = false;
            // 
            // circularpictureleft1
            // 
            this.circularpictureleft1.BackColor = System.Drawing.Color.White;
            this.circularpictureleft1.Location = new System.Drawing.Point(-130, 304);
            this.circularpictureleft1.Name = "circularpictureleft1";
            this.circularpictureleft1.Size = new System.Drawing.Size(433, 461);
            this.circularpictureleft1.TabIndex = 45;
            this.circularpictureleft1.TabStop = false;
            // 
            // anh6
            // 
            this.anh6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(250)))));
            this.anh6.Image = global::GameOAnQuan.Properties.Resources.anhchu1_1;
            this.anh6.Location = new System.Drawing.Point(1114, 327);
            this.anh6.Name = "anh6";
            this.anh6.Size = new System.Drawing.Size(364, 409);
            this.anh6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.anh6.TabIndex = 53;
            this.anh6.TabStop = false;
            // 
            // circularpictureright1
            // 
            this.circularpictureright1.BackColor = System.Drawing.Color.White;
            this.circularpictureright1.Location = new System.Drawing.Point(1109, 303);
            this.circularpictureright1.Name = "circularpictureright1";
            this.circularpictureright1.Size = new System.Drawing.Size(421, 462);
            this.circularpictureright1.TabIndex = 51;
            this.circularpictureright1.TabStop = false;
            // 
            // elipseControl1
            // 
            this.elipseControl1.CornerRadius = 70;
            this.elipseControl1.TargetControl = this.panel1;
            // 
            // elipseControl2
            // 
            this.elipseControl2.CornerRadius = 50;
            this.elipseControl2.TargetControl = this;
            // 
            // elipseControl3
            // 
            this.elipseControl3.CornerRadius = 70;
            this.elipseControl3.TargetControl = this.anhsoluongsoicuamay;
            // 
            // elipseControl4
            // 
            this.elipseControl4.CornerRadius = 70;
            this.elipseControl4.TargetControl = this.anhsoluongsoicuanguoi;
            // 
            // elipseControl5
            // 
            this.elipseControl5.CornerRadius = 50;
            this.elipseControl5.TargetControl = this.anhnguoichoi;
            // 
            // elipseControl6
            // 
            this.elipseControl6.CornerRadius = 70;
            this.elipseControl6.TargetControl = this.anhnguoimay;
            // 
            // elipseControl7
            // 
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1814, 1055);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.nguoichoi);
            this.Controls.Add(this.anh12);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.circularpictureleft1);
            this.Controls.Add(this.anh6);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.circularpictureright1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.anhnguoimay);
            this.Controls.Add(this.anhnguoichoi);
            this.Controls.Add(this.anhsoluongsoicuamay);
            this.Controls.Add(this.anhsoluongsoicuanguoi);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.lbldiemmay);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.lbldiemnguoichoi);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "Game";
            this.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowIcon = false;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhnguoimay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhnguoichoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhsoluongsoicuamay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhsoluongsoicuanguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circularpictureleft1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anh6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circularpictureright1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label t2;
        private System.Windows.Forms.Label t1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbldiemmay;
        private System.Windows.Forms.Label lbldiemnguoichoi;
        private System.Windows.Forms.Button btnchoilai;
        private System.Windows.Forms.PictureBox anhnguoimay;
        private System.Windows.Forms.PictureBox anhsoluongsoicuanguoi;
        private System.Windows.Forms.PictureBox anhsoluongsoicuamay;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.PictureBox anhnguoichoi;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox anh2;
        private System.Windows.Forms.PictureBox anh7;
        private System.Windows.Forms.PictureBox anh8;
        private System.Windows.Forms.PictureBox anh9;
        private System.Windows.Forms.PictureBox anh10;
        private System.Windows.Forms.PictureBox anh11;
        private System.Windows.Forms.PictureBox anh5;
        private System.Windows.Forms.PictureBox anh4;
        private System.Windows.Forms.PictureBox anh3;
        private System.Windows.Forms.PictureBox anh1;
        private Circularpictureright circularpictureright1;
        private Circularpictureright anh6;
        private System.Windows.Forms.Button btn6;
        private Circularpictureleft circularpictureleft1;
        private Circularpictureleft anh12;
        private System.Windows.Forms.Button btn12;
        private ElipseControl elipseControl1;
        private ElipseControl elipseControl2;
        private ElipseControl elipseControl3;
        private ElipseControl elipseControl4;
        private ElipseControl elipseControl5;
        private ElipseControl elipseControl6;
        private System.Windows.Forms.Label nguoichoi;
        private ElipseControl elipseControl7;
        private ElipseControl elipseControl8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

